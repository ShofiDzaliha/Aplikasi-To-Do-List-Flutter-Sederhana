package com.example.project_flutter_shofi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
