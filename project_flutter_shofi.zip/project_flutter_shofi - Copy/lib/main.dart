// lib/main.dart
// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';

void main() {
  runApp(const TodoApp());
}

/// ======================
/// Models & State
/// ======================
class Task {
  String id;
  String title;
  String? description;
  DateTime createdAt;
  DateTime? dueDate;
  bool done;
  Task({
    required this.id,
    required this.title,
    this.description,
    DateTime? createdAt,
    this.dueDate,
    this.done = false,
  }) : createdAt = createdAt ?? DateTime.now();

  Task copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? createdAt,
    DateTime? dueDate,
    bool? done,
  }) => Task(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    createdAt: createdAt ?? this.createdAt,
    dueDate: dueDate ?? this.dueDate,
    done: done ?? this.done,
  );
}

class TaskManager extends ChangeNotifier {
  final List<Task> _tasks = [];

  List<Task> get tasks => List.unmodifiable(_tasks);

  void add(Task t) {
    _tasks.insert(0, t);
    notifyListeners();
  }

  void update(String id, Task updated) {
    final i = _tasks.indexWhere((t) => t.id == id);
    if (i >= 0) {
      _tasks[i] = updated;
      notifyListeners();
    }
  }

  void remove(String id) {
    _tasks.removeWhere((t) => t.id == id);
    notifyListeners();
  }

  void toggleDone(String id) {
    final i = _tasks.indexWhere((t) => t.id == id);
    if (i >= 0) {
      _tasks[i] = _tasks[i].copyWith(done: !_tasks[i].done);
      notifyListeners();
    }
  }

  void clearCompleted() {
    _tasks.removeWhere((t) => t.done);
    notifyListeners();
  }

  void reorder(int oldIndex, int newIndex) {
    if (oldIndex < newIndex) newIndex -= 1;
    final item = _tasks.removeAt(oldIndex);
    _tasks.insert(newIndex, item);
    notifyListeners();
  }
}

/// Provide TaskManager via InheritedNotifier
class TaskProvider extends InheritedNotifier<TaskManager> {
  const TaskProvider({
    super.key,
    required TaskManager manager,
    required super.child,
  }) : super(notifier: manager);

  static TaskManager of(BuildContext context) {
    final provider = context.dependOnInheritedWidgetOfExactType<TaskProvider>();
    assert(provider != null, 'No TaskProvider found in context');
    return provider!.notifier!;
  }
}

/// ======================
/// Design tokens (Soft Blue Pastel)
/// ======================
const Color kPrimary = Color(0xFF4A90E2);
const Color kPrimarySoft = Color(0xFFEAF4FF);
const Color kSurface = Color(0xFFFFFFFF);
const Color kMuted = Color(0xFF6B7280);
const double kRadius = 16.0;

/// Predefined vertical gradient accents for list items (pastel variants)
final List<Gradient> kAccents = [
  const LinearGradient(
    colors: [Color(0xFF89F7FE), Color(0xFF66A6FF)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
  const LinearGradient(
    colors: [Color(0xFFFFE29A), Color(0xFFFF9A9E)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
  const LinearGradient(
    colors: [Color(0xFFD4FC79), Color(0x0096e6a6)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
  const LinearGradient(
    colors: [Color(0xFFB9FFFC), Color(0xFFB0EFFF)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
  const LinearGradient(
    colors: [Color(0xFFC7CEFF), Color(0xFFF6C6FF)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  ),
];

/// Utility: choose accent based on id hash
Gradient accentFor(String id) {
  final idx = id.hashCode.abs() % kAccents.length;
  return kAccents[idx];
}

/// ======================
/// App Root
/// ======================
class TodoApp extends StatefulWidget {
  const TodoApp({super.key});
  @override
  State<TodoApp> createState() => _TodoAppState();
}

class _TodoAppState extends State<TodoApp> {
  final TaskManager manager = TaskManager();
  bool useDark = false;

  @override
  void initState() {
    super.initState();
    // sample tasks
    manager.add(
      Task(
        id: 't1',
        title: 'Belanja bahan kue',
        description: 'Tepung, gula, ragi',
      ),
    );
    manager.add(
      Task(
        id: 't2',
        title: 'Commit project',
        dueDate: DateTime.now().add(const Duration(days: 1)),
      ),
    );
    manager.add(
      Task(
        id: 't3',
        title: 'Baca materi ACO',
        description: 'Persiapan makalah',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TaskProvider(
      manager: manager,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Soft To-Do',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: kPrimary,
            brightness: Brightness.light,
          ),
          primaryColor: kPrimary,
          scaffoldBackgroundColor: kPrimarySoft,
          appBarTheme: const AppBarTheme(
            centerTitle: true,
            elevation: 0,
            backgroundColor: kPrimary,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(kRadius),
              borderSide: BorderSide.none,
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: kPrimary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        darkTheme: ThemeData.dark(),
        themeMode: useDark ? ThemeMode.dark : ThemeMode.light,
        initialRoute: '/',
        routes: {
          '/': (_) =>
              HomePage(onToggleTheme: () => setState(() => useDark = !useDark)),
          '/add': (_) => const AddTaskPage(),
          '/settings': (_) => SettingsPage(
            useDark: useDark,
            onToggle: () => setState(() => useDark = !useDark),
          ),
        },
        onGenerateRoute: (settings) {
          final uri = Uri.parse(settings.name ?? '');
          if (uri.pathSegments.isEmpty) return null;
          if (uri.pathSegments.length == 2 && uri.pathSegments[0] == 'detail') {
            final id = uri.pathSegments[1];
            return MaterialPageRoute(
              builder: (_) => TaskDetailPage(taskId: id),
            );
          }
          if (uri.pathSegments.length == 2 && uri.pathSegments[0] == 'edit') {
            final id = uri.pathSegments[1];
            return MaterialPageRoute(builder: (_) => EditTaskPage(taskId: id));
          }
          return null;
        },
      ),
    );
  }
}

/// ======================
/// Pages
/// ======================

class HomePage extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const HomePage({super.key, required this.onToggleTheme});
  @override
  State<HomePage> createState() => _HomePageState();
}

enum FilterMode { all, active, completed, dueSoon }

class _HomePageState extends State<HomePage> {
  String query = '';
  FilterMode filter = FilterMode.all;

  @override
  Widget build(BuildContext context) {
    final manager = TaskProvider.of(context);
    final all = manager.tasks;
    final filtered = all.where((t) {
      if (query.isNotEmpty &&
          !t.title.toLowerCase().contains(query.toLowerCase()) &&
          (t.description ?? '').toLowerCase().contains(query.toLowerCase()) ==
              false) {
        return false;
      }
      switch (filter) {
        case FilterMode.active:
          return !t.done;
        case FilterMode.completed:
          return t.done;
        case FilterMode.dueSoon:
          return t.dueDate != null &&
              t.dueDate!.isBefore(DateTime.now().add(const Duration(days: 3)));
        case FilterMode.all:
          return true;
      }
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('To-Do List'),
        actions: [
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/settings'),
            icon: const Icon(Icons.settings),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // search + filter
            Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: (v) => setState(() => query = v),
                    decoration: const InputDecoration(
                      hintText: 'Cari tugas...',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                FilledButton.tonalIcon(
                  icon: const Icon(Icons.filter_list),
                  label: const Text('Filter'),
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    builder: (_) => Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ListTile(
                            title: const Text('Semua'),
                            leading: Radio<FilterMode>(
                              value: FilterMode.all,
                              groupValue: filter,
                              onChanged: (v) => setState(() => filter = v!),
                            ),
                          ),
                          ListTile(
                            title: const Text('Belum selesai'),
                            leading: Radio<FilterMode>(
                              value: FilterMode.active,
                              groupValue: filter,
                              onChanged: (v) => setState(() => filter = v!),
                            ),
                          ),
                          ListTile(
                            title: const Text('Selesai'),
                            leading: Radio<FilterMode>(
                              value: FilterMode.completed,
                              groupValue: filter,
                              onChanged: (v) => setState(() => filter = v!),
                            ),
                          ),
                          ListTile(
                            title: const Text('Jatuh tempo dekat'),
                            leading: Radio<FilterMode>(
                              value: FilterMode.dueSoon,
                              groupValue: filter,
                              onChanged: (v) => setState(() => filter = v!),
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // summary card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: kSurface,
                borderRadius: BorderRadius.circular(kRadius),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 10,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Your Tasks',
                          style: TextStyle(color: kMuted, fontSize: 12),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${all.length} tugas',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  CircleAvatar(
                    backgroundColor: kPrimary,
                    child: const Icon(Icons.check, color: Colors.white),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // list
            Expanded(
              child: filtered.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.inbox, size: 56, color: kMuted),
                          SizedBox(height: 10),
                          Text(
                            'Belum ada tugas',
                            style: TextStyle(color: kMuted),
                          ),
                        ],
                      ),
                    )
                  : ReorderableListView.builder(
                      onReorder: (oldIndex, newIndex) =>
                          manager.reorder(oldIndex, newIndex),
                      itemCount: filtered.length,
                      itemBuilder: (ctx, index) {
                        final t = filtered[index];
                        final gradient = accentFor(t.id);
                        return Container(
                          key: ValueKey(t.id),
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          child: Material(
                            elevation: 4,
                            borderRadius: BorderRadius.circular(20),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(20),
                              onTap: () => Navigator.pushNamed(
                                context,
                                '/detail/${t.id}',
                              ),
                              child: Row(
                                children: [
                                  // gradient vertical accent
                                  Container(
                                    width: 8,
                                    height: 80,
                                    decoration: BoxDecoration(
                                      gradient: gradient,
                                      borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(20),
                                        bottomLeft: Radius.circular(20),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 12,
                                        horizontal: 6,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  t.title,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w700,
                                                    color: t.done
                                                        ? kMuted
                                                        : Colors.black,
                                                  ),
                                                ),
                                              ),
                                              if (t.dueDate != null)
                                                Text(
                                                  formatDate(t.dueDate!),
                                                  style: const TextStyle(
                                                    color: kMuted,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                            ],
                                          ),
                                          const SizedBox(height: 6),
                                          if (t.description != null)
                                            Text(
                                              t.description!,
                                              style: const TextStyle(
                                                color: kMuted,
                                                fontSize: 13,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                    ),
                                    child: IconButton(
                                      onPressed: () => Navigator.pushNamed(
                                        context,
                                        '/edit/${t.id}',
                                      ),
                                      icon: const Icon(
                                        Icons.edit,
                                        color: kPrimary,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 12),
                                    child: IconButton(
                                      onPressed: () => manager.remove(t.id),
                                      icon: const Icon(
                                        Icons.delete_outline,
                                        color: kMuted,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/add'),
        backgroundColor: kPrimary,
        child: const Icon(Icons.add),
      ),
    );
  }
}

/// Add Task Page
class AddTaskPage extends StatefulWidget {
  const AddTaskPage({super.key});
  @override
  State<AddTaskPage> createState() => _AddTaskPageState();
}

class _AddTaskPageState extends State<AddTaskPage> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  DateTime? _due;

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final manager = TaskProvider.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Tugas')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: _title,
              decoration: const InputDecoration(hintText: 'Judul tugas'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _desc,
              decoration: const InputDecoration(
                hintText: 'Deskripsi (opsional)',
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    _due == null
                        ? 'Tidak ada tanggal jatuh tempo'
                        : 'Jatuh tempo: ${formatDate(_due!)}',
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    final now = DateTime.now();
                    final pick = await showDatePicker(
                      context: context,
                      initialDate: now,
                      firstDate: now.subtract(const Duration(days: 365)),
                      lastDate: now.add(const Duration(days: 365 * 5)),
                    );
                    if (pick != null) {
                      if (!mounted) return;
                      final time = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                      );
                      setState(() {
                        _due = DateTime(
                          pick.year,
                          pick.month,
                          pick.day,
                          time?.hour ?? 0,
                          time?.minute ?? 0,
                        );
                      });
                    }
                  },
                  child: const Text('Pilih tanggal'),
                ),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  if ((_formKey.currentState?.validate() ?? true) &&
                      _title.text.trim().isNotEmpty) {
                    final t = Task(
                      id: UniqueKey().toString(),
                      title: _title.text.trim(),
                      description: _desc.text.trim().isEmpty
                          ? null
                          : _desc.text.trim(),
                      dueDate: _due,
                    );
                    manager.add(t);
                    Navigator.pop(context);
                  } else {
                    // simple validation feedback
                    if (_title.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Judul wajib diisi')),
                      );
                    }
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: Text(
                    'Simpan',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Task Detail Page
class TaskDetailPage extends StatelessWidget {
  final String taskId;
  const TaskDetailPage({super.key, required this.taskId});
  @override
  Widget build(BuildContext context) {
    final manager = TaskProvider.of(context);
    final task = manager.tasks.firstWhere(
      (t) => t.id == taskId,
      orElse: () => Task(id: 'notfound', title: 'Tugas tidak ditemukan'),
    );
    if (task.id == 'notfound') {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail')),
        body: const Center(child: Text('Tugas tidak ditemukan')),
      );
    }
    final gradient = accentFor(task.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Detail Tugas')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                color: kSurface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 110,
                    decoration: BoxDecoration(
                      gradient: gradient,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(20),
                        bottomLeft: Radius.circular(20),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(14.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            task.title,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 8),
                          if (task.description != null)
                            Text(
                              task.description!,
                              style: const TextStyle(color: kMuted),
                            ),
                          const SizedBox(height: 12),
                          Text(
                            'Dibuat: ${formatDate(task.createdAt)}',
                            style: const TextStyle(color: kMuted),
                          ),
                          if (task.dueDate != null)
                            Text(
                              'Jatuh tempo: ${formatDate(task.dueDate!)}',
                              style: const TextStyle(color: kMuted),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    icon: Icon(
                      task.done ? Icons.close_rounded : Icons.check,
                      color: Colors.white,
                    ),
                    label: Text(
                      task.done ? 'Tandai belum selesai' : 'Tandai selesai',
                    ),
                    onPressed: () {
                      final copy = task.copyWith(done: !task.done);
                      manager.update(task.id, copy);
                    },
                  ),
                ),
                const SizedBox(width: 12),
                OutlinedButton.icon(
                  onPressed: () =>
                      Navigator.pushNamed(context, '/edit/${task.id}'),
                  icon: const Icon(Icons.edit),
                  label: const Text('Edit'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Edit Task Page
class EditTaskPage extends StatefulWidget {
  final String taskId;
  const EditTaskPage({super.key, required this.taskId});
  @override
  State<EditTaskPage> createState() => _EditTaskPageState();
}

class _EditTaskPageState extends State<EditTaskPage> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  DateTime? _due;
  bool _initialized = false;

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    super.dispose();
  }

  void _initFromTask(Task t) {
    if (_initialized) return;
    _title.text = t.title;
    _desc.text = t.description ?? '';
    _due = t.dueDate;
    _initialized = true;
  }

  @override
  Widget build(BuildContext context) {
    final manager = TaskProvider.of(context);
    final task = manager.tasks.firstWhere(
      (t) => t.id == widget.taskId,
      orElse: () => Task(id: 'notfound', title: 'Tugas tidak ditemukan'),
    );
    if (task.id == 'notfound') {
      return Scaffold(
        appBar: AppBar(title: const Text('Edit')),
        body: const Center(child: Text('Tugas tidak ditemukan')),
      );
    }
    _initFromTask(task);

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Tugas')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: _title,
              decoration: const InputDecoration(hintText: 'Judul tugas'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _desc,
              decoration: const InputDecoration(
                hintText: 'Deskripsi (opsional)',
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    _due == null
                        ? 'Tidak ada tanggal jatuh tempo'
                        : 'Jatuh tempo: ${formatDate(_due!)}',
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    final now = DateTime.now();
                    final pick = await showDatePicker(
                      context: context,
                      initialDate: _due ?? now,
                      firstDate: now.subtract(const Duration(days: 365)),
                      lastDate: now.add(const Duration(days: 365 * 5)),
                    );
                    if (pick != null) {
                      if (!mounted) return;
                      final time = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.fromDateTime(
                          _due ?? DateTime.now(),
                        ),
                      );
                      setState(() {
                        _due = DateTime(
                          pick.year,
                          pick.month,
                          pick.day,
                          time?.hour ?? 0,
                          time?.minute ?? 0,
                        );
                      });
                    }
                  },
                  child: const Text('Pilih tanggal'),
                ),
                if (_due != null)
                  IconButton(
                    onPressed: () => setState(() => _due = null),
                    icon: const Icon(Icons.clear),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  if ((_formKey.currentState?.validate() ?? true) &&
                      _title.text.trim().isNotEmpty) {
                    final updated = task.copyWith(
                      title: _title.text.trim(),
                      description: _desc.text.trim().isEmpty
                          ? null
                          : _desc.text.trim(),
                      dueDate: _due,
                    );
                    manager.update(task.id, updated);
                    Navigator.pop(context);
                  } else {
                    if (_title.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Judul wajib diisi')),
                      );
                    }
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: Text(
                    'Simpan perubahan',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Settings Page
class SettingsPage extends StatelessWidget {
  final bool useDark;
  final VoidCallback onToggle;
  const SettingsPage({
    super.key,
    required this.useDark,
    required this.onToggle,
  });
  @override
  Widget build(BuildContext context) {
    final manager = TaskProvider.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: SwitchListTile(
                value: useDark,
                onChanged: (_) => onToggle(),
                title: const Text('Dark mode'),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('Jumlah tugas'),
                subtitle: Text('${manager.tasks.length} tugas'),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                leading: const Icon(Icons.delete_sweep),
                title: const Text('Reset semua tugas'),
                trailing: FilledButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Reset semua tugas'),
                        content: const Text(
                          'Menghapus semua tugas? Tindakan ini tidak dapat dibatalkan.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: const Text('Batal'),
                          ),
                          TextButton(
                            onPressed: () {
                              final ids = manager.tasks
                                  .map((t) => t.id)
                                  .toList();
                              for (final id in ids) {
                                manager.remove(id);
                              }
                              Navigator.pop(ctx);
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Semua tugas dihapus'),
                                ),
                              );
                            },
                            child: const Text('Hapus'),
                          ),
                        ],
                      ),
                    );
                  },
                  child: const Text('Hapus'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ======================
/// Utilities
/// ======================
String formatDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
}
